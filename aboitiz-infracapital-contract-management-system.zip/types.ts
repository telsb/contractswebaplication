
export const Estate = {
    LIMA: "LIMA Estate",
    BIZHUB: "BizHub",
    TARI: "TARI Estate",
    MEZ2: "MEZ2 Estate",
    WEST_CEBU: "WEST CEBU Estate",
    ADMIN: "ADMIN",
    ALL: "ALL"
};

export const ContractType = {
    LOI: "LOI",
    RA: "RA",
    CTS: "CTS",
    DOAS: "DOAS",
    LTLA: "LTLA",
    OTHERS: "OTHERS",
};
